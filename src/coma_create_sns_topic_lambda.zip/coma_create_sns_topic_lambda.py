#!/usr/bin/env python
"""

This Lambda function creates an SNS topic and subscribes the provided emails.
The subscribed will receive an email to confirm the subscription. 
The function inputs are the topic name and list of emails.
The function returns the ARN of the created topic.

Tested with: 
* 

Set up the following as Lambda environment variables:
    EmailAddressStringList      Required: The mail list for the notification (semi-colon seperated line)
    TopicName                   Required: Name of SNS topic

@author Andrew Citera
@date May 2018       
"""

import boto3
import logging
import os
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)
     
def lambda_handler(event, context):
    
    #Process Lambda environment variables
    try:
        EmailAddressStringList = os.environ['EmailAddressStringList']
        TopicName = os.environ['TopicName']
    except:
        print("FATAL ERROR. Lambda environment variable(s) not set.")
        return "Failed"

    #Assign SNS client
    sns_client = boto3.client('sns')

    #Define SNS create topic function
    topic = sns_client.create_topic(
        Name=TopicName
    )

    #Call SNS create topic function
    topic

    #Split EmailAddressStringList on semi-colin ";"
    EmailAddressStringList_Split = EmailAddressStringList.split(";")

    #Iterate through EmailAddressStringList_Split and create subscription for each email
    for email in EmailAddressStringList_Split:
        #Define subscribe function 
        subscription = sns_client.subscribe(
            TopicArn=topic['TopicArn'],
            Protocol='email',
            Endpoint=email.strip()
        )
        #Call subscription function
        subscription
       
    #Return ARN of created topic
    return topic['TopicArn']         